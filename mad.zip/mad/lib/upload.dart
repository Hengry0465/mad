import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:open_file/open_file.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_file_service.dart';

class UploadPage extends StatefulWidget {
  const UploadPage({Key? key}) : super(key: key);

  @override
  _UploadPageState createState() => _UploadPageState();
}

class _UploadPageState extends State<UploadPage> {
  List<FirebaseFileInfo> uploadedFiles = [];
  bool isLoading = true;
  final FirebaseFileService _fileService = FirebaseFileService();

  @override
  void initState() {
    super.initState();
    _requestPermissions();
    _loadFiles();
  }

  Future<void> _requestPermissions() async {
    // Request storage permissions
    await [Permission.storage].request();
  }

  Future<void> _loadFiles() async {
    setState(() {
      isLoading = true;
    });

    try {
      // Check if user is logged in
      if (FirebaseAuth.instance.currentUser == null) {
        // Navigate to login screen
        Navigator.pushReplacementNamed(context, '/login');
        return;
      }

      // Get files from Firestore
      final files = await _fileService.getFiles();
      setState(() {
        uploadedFiles = files;
        isLoading = false;
      });
    } catch (e) {
      print('Error loading files: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> _pickFile() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles();

      if (result != null) {
        final path = result.files.single.path;
        final name = result.files.single.name;

        if (path != null && name != null) {
          // Show loading indicator
          setState(() {
            isLoading = true;
          });

          // Check if the file is a PDF and if it is password protected
          bool isPasswordProtected = false;
          if (name.toLowerCase().endsWith('.pdf')) {
            // For simplicity in this demonstration, we'll add a UI dialog to ask the user
            // if the PDF is password protected instead of auto-detection
            isPasswordProtected = await _showPasswordProtectionDialog(
              context,
              name,
            );
          }

          // Create a file to get size and other info
          final file = File(path);

          // Upload to Firebase
          final fileId = await _fileService.uploadFile(
            file,
            name,
            isPasswordProtected: isPasswordProtected,
          );

          // Reload the files list
          await _loadFiles();

          // Show success message
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('File uploaded successfully to Firebase')),
          );
        }
      }
    } catch (e) {
      print('Error picking file: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error uploading file: $e')),
      );
      setState(() {
        isLoading = false;
      });
    }
  }

  // Method to show a dialog asking if the PDF is password protected
  Future<bool> _showPasswordProtectionDialog(
      BuildContext context,
      String fileName,
      ) async {
    bool isPasswordProtected = false;

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('PDF Protection'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [Text('Is "$fileName" password protected?')],
        ),
        actions: [
          TextButton(
            onPressed: () {
              isPasswordProtected = false;
              Navigator.of(context).pop();
            },
            child: const Text('No'),
          ),
          TextButton(
            onPressed: () {
              isPasswordProtected = true;
              Navigator.of(context).pop();
            },
            child: const Text('Yes'),
          ),
        ],
      ),
    );

    return isPasswordProtected;
  }

  void _showFileDetails(FirebaseFileInfo fileInfo) async {
    // Show loading indicator
    setState(() {
      isLoading = true;
    });

    try {
      // Download the file
      final fileBytes = await _fileService.downloadFile(fileInfo.id);

      // Save to temporary file for viewing
      final tempPath = await _fileService.saveFileToDisk(fileBytes, fileInfo.name);

      setState(() {
        isLoading = false;
      });

      // Navigate to file details page
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => FirebaseFileDetailPage(
            fileInfo: fileInfo,
            filePath: tempPath,
            onDelete: _deleteFile,
          ),
        ),
      );
    } catch (e) {
      print('Error downloading file: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error opening file: $e')),
      );
      setState(() {
        isLoading = false;
      });
    }
  }

  void _deleteFile(FirebaseFileInfo fileInfo) async {
    try {
      await _fileService.deleteFile(fileInfo.id);
      await _loadFiles();
    } catch (e) {
      print('Error deleting file: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error deleting file: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.grey[100],
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            // Handle back navigation
            Navigator.of(context).pop();
          },
        ),
        title: const Text(
          'Upload File',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        actions: [
          // Sign out button
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.black),
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 24.0),
        child: isLoading
            ? const Center(child: CircularProgressIndicator())
            : Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Upload Area
            GestureDetector(
              onTap: _pickFile,
              child: DottedBorder(
                borderType: BorderType.RRect,
                radius: const Radius.circular(8),
                color: Colors.black,
                strokeWidth: 1,
                dashPattern: const [5, 5],
                child: Container(
                  width: double.infinity,
                  height: 180,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(
                          Icons.cloud_upload_outlined,
                          size: 50,
                          color: Colors.black,
                        ),
                        SizedBox(height: 8),
                        Text(
                          'Upload your file here',
                          style: TextStyle(fontSize: 16, color: Colors.black),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Files will be encrypted and stored in Firebase',
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 40),

            // Always show the "Recent Uploaded File" section
            Container(
              alignment: Alignment.centerRight,
              child: Column(
                children: [
                  const Text(
                    'Recent Uploaded Files',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  Container(
                    height: 1,
                    width: 180,
                    color: Colors.black,
                    margin: const EdgeInsets.only(top: 2),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // List of uploaded files (if any)
            if (uploadedFiles.isNotEmpty)
              Expanded(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: uploadedFiles.length,
                  itemBuilder: (context, index) {
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: ListTile(
                        title: Text(uploadedFiles[index].name),
                        subtitle: Text(
                          uploadedFiles[index].formattedSize,
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (uploadedFiles[index].isPasswordProtected)
                              const Icon(
                                Icons.lock,
                                size: 16,
                                color: Colors.orange,
                              ),
                            const SizedBox(width: 8),
                            const Icon(Icons.arrow_forward_ios, size: 16),
                          ],
                        ),
                        onTap: () {
                          // Show file details when tapped
                          _showFileDetails(uploadedFiles[index]);
                        },
                      ),
                    );
                  },
                ),
              ),

            if (uploadedFiles.isEmpty)
              const Expanded(
                child: Center(
                  child: Text(
                    "No files uploaded yet",
                    style: TextStyle(color: Colors.grey, fontSize: 16),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// File Details Page for Firebase files
class FirebaseFileDetailPage extends StatefulWidget {
  final FirebaseFileInfo fileInfo;
  final String filePath;
  final Function(FirebaseFileInfo) onDelete;

  const FirebaseFileDetailPage({
    Key? key,
    required this.fileInfo,
    required this.filePath,
    required this.onDelete,
  }) : super(key: key);

  @override
  _FirebaseFileDetailPageState createState() => _FirebaseFileDetailPageState();
}

class _FirebaseFileDetailPageState extends State<FirebaseFileDetailPage> {
  bool isLoading = false;
  Uint8List? filePreview;
  String? pdfPassword; // Store PDF password if provided

  @override
  void initState() {
    super.initState();
    _loadFilePreview();
  }

  Future<void> _loadFilePreview() async {
    if (['jpg', 'jpeg', 'png', 'gif'].contains(widget.fileInfo.fileExtension.toLowerCase())) {
      setState(() {
        isLoading = true;
      });

      try {
        // Load the file as bytes for preview
        final file = File(widget.filePath);
        final bytes = await file.readAsBytes();

        setState(() {
          filePreview = bytes;
          isLoading = false;
        });
      } catch (e) {
        print('Error loading preview: $e');
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Future<void> _openFile() async {
    try {
      final extension = widget.fileInfo.fileExtension.toLowerCase();

      if (['jpg', 'jpeg', 'png', 'gif'].contains(extension) && filePreview != null) {
        // Image viewer is built into the UI
        showDialog(
          context: context,
          builder: (context) => Dialog(
            child: Container(
              constraints: const BoxConstraints(
                maxWidth: double.infinity,
                maxHeight: 500,
              ),
              child: Image.memory(filePreview!, fit: BoxFit.contain),
            ),
          ),
        );
      } else if (extension == 'pdf') {
        // For PDF files with password protection
        if (widget.fileInfo.isPasswordProtected) {
          if (pdfPassword == null) {
            // If password isn't set, prompt for it
            _showPdfPasswordDialog(context);
            return;
          }

          // If we have a password, use it to open the PDF directly
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PDFViewPage(
                filePath: widget.filePath,
                password: pdfPassword,
              ),
            ),
          );
        } else {
          // For non-password protected PDFs
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PDFViewPage(
                filePath: widget.filePath,
              ),
            ),
          );
        }
      } else {
        // For other file types, use OpenFile
        final result = await OpenFile.open(widget.filePath);
        if (result.type != ResultType.done) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error: ${result.message}')),
          );
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  // Method to show PDF password dialog
  void _showPdfPasswordDialog(BuildContext context) {
    final TextEditingController passwordController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('PDF Password'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'This PDF is password-protected. Please enter the password:',
            ),
            const SizedBox(height: 16),
            TextField(
              controller: passwordController,
              decoration: const InputDecoration(
                labelText: 'PDF Password',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                pdfPassword = passwordController.text;
              });
              Navigator.of(context).pop();

              // Try opening with the provided password
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PDFViewPage(
                    filePath: widget.filePath,
                    password: pdfPassword,
                  ),
                ),
              );
            },
            child: const Text('Open PDF'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.grey[100],
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        title: const Text(
          'File Details',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildFilePreview(),
            const SizedBox(height: 24),
            _buildDetailItem(context, 'File Name', widget.fileInfo.name),
            _buildDetailItem(
              context,
              'File Type',
              widget.fileInfo.fileExtension.toUpperCase(),
            ),
            _buildDetailItem(
              context,
              'File Size',
              widget.fileInfo.formattedSize,
            ),
            _buildDetailItem(
              context,
              'Date Added',
              widget.fileInfo.formattedDate,
            ),
            _buildDetailItem(
              context,
              'Encrypted',
              widget.fileInfo.isEncrypted ? 'Yes' : 'No',
            ),
            _buildDetailItem(
              context,
              'Password Protected',
              widget.fileInfo.isPasswordProtected ? 'Yes' : 'No',
            ),
            _buildDetailItem(
              context,
              'Cloud Storage',
              'Yes (Firebase)',
            ),
            if (pdfPassword != null && widget.fileInfo.isPasswordProtected)
              _buildDetailItem(context, 'PDF Password', '••••••••'),
            const SizedBox(height: 32),
            _buildActionButtons(context),
          ],
        ),
      ),
    );
  }

  Widget _buildFilePreview() {
    if (filePreview != null &&
        ['jpg', 'jpeg', 'png', 'gif'].contains(widget.fileInfo.fileExtension.toLowerCase())) {
      // If we have image preview data, show it
      return Container(
        height: 200,
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          color: Colors.grey[200],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.memory(filePreview!, fit: BoxFit.contain),
        ),
      );
    }

    // Otherwise show the file icon
    IconData iconData;
    Color iconColor;

    final extension = widget.fileInfo.fileExtension.toLowerCase();

    if (['jpg', 'jpeg', 'png', 'gif'].contains(extension)) {
      iconData = Icons.image;
      iconColor = Colors.blue;
    } else if (['pdf'].contains(extension)) {
      iconData = Icons.picture_as_pdf;
      iconColor = Colors.red;
    } else if (['doc', 'docx'].contains(extension)) {
      iconData = Icons.description;
      iconColor = Colors.indigo;
    } else if (['xls', 'xlsx'].contains(extension)) {
      iconData = Icons.table_chart;
      iconColor = Colors.green;
    } else {
      iconData = Icons.insert_drive_file;
      iconColor = Colors.grey;
    }

    return Center(
      child: Column(
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              Icon(iconData, size: 80, color: iconColor),
              if (isLoading) const CircularProgressIndicator(),
              if (widget.fileInfo.isEncrypted ||
                  widget.fileInfo.isPasswordProtected)
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      color: Colors.black,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.lock,
                      color: Colors.white,
                      size: 16,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            widget.fileInfo.name,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailItem(BuildContext context, String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 150,
            child: Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.grey,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: ElevatedButton.icon(
            icon: const Icon(Icons.open_in_new),
            label: const Text('Open File'),
            style: ElevatedButton.styleFrom(
              foregroundColor: Colors.white,
              backgroundColor: Colors.blue,
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            onPressed: isLoading ? null : _openFile,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: OutlinedButton.icon(
            icon: const Icon(Icons.delete_outline),
            label: const Text('Delete'),
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.red,
              side: const BorderSide(color: Colors.red),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            onPressed: () {
              // Show delete confirmation dialog
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Delete File'),
                  content: Text(
                    'Are you sure you want to delete ${widget.fileInfo.name}? This will remove it from Firebase.',
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Cancel'),
                    ),
                    TextButton(
                      onPressed: () {
                        widget.onDelete(widget.fileInfo);
                        Navigator.of(context).pop();
                        Navigator.of(context).pop();
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('File deleted from Firebase')),
                        );
                      },
                      child: const Text(
                        'Delete',
                        style: TextStyle(color: Colors.red),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

// PDF View Page (same as before)
class PDFViewPage extends StatelessWidget {
  final String filePath;
  final String? password;

  const PDFViewPage({Key? key, required this.filePath, this.password})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('PDF Viewer'),
        backgroundColor: Colors.grey[100],
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: PDFView(
        filePath: filePath,
        password: password, // Pass the password to the PDFView
        enableSwipe: true,
        swipeHorizontal: true,
        autoSpacing: false,
        pageFling: false,
        pageSnap: true,
        defaultPage: 0,
        fitPolicy: FitPolicy.BOTH,
        preventLinkNavigation: false,
        onRender: (_pages) {
          // PDF rendered
        },
        onError: (error) {
          // Handle errors - especially password errors
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error: $error'),
              duration: const Duration(seconds: 5),
            ),
          );
          // Go back if there's an error (likely wrong password)
          Navigator.of(context).pop();
        },
        onPageError: (page, error) {
          // Handle page errors
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error on page $page: $error')),
          );
        },
        onPageChanged: (int? page, int? total) {
          // Page changed
        },
        onViewCreated: (PDFViewController pdfViewController) {
          // PDF view created
        },
      ),
    );
  }
}